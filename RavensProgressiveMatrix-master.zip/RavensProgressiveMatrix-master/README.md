# RavensProgressiveMatrix

The main objective of this project was to design AI Agent that could solve a 2x2 and 3x3 Raven’s Progressive Matrix problem. These types of problems are intelligence tests of abstract reasoning of which the goal is to state what is the missing item to complete a provided pattern.

The Agent has been programmed to use a visual and verbal approach to solve the various problems. 

Python libraries used: Pillow & Numpy for Image Recognition

